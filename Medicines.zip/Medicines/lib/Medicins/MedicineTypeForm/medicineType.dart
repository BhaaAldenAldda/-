import 'package:flutter/cupertino.dart';

class MedicineType {
  String name;
  Widget image;
  bool isChoose;
  MedicineType(this.name, this.image, this.isChoose);
}
